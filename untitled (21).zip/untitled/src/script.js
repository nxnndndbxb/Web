// admin_app.js
document.addEventListener('DOMContentLoaded', () => {
    // Firebase configuration (COPY FROM YOUR USER APP's JS)
    const firebaseConfig = {
        apiKey: "AIzaSyCDJDsUZ-RwkC5h2LH7mRql1SSixINGT-8", 
        authDomain: "video-apk-8af78.firebaseapp.com",
        databaseURL: "https://video-apk-8af78-default-rtdb.asia-southeast1.firebasedatabase.app/",
        projectId: "video-apk-8af78",
        storageBucket: "video-apk-8af78.appspot.com",
        messagingSenderId: "1234567890", // Replace
        appId: "1:272112220572:android:d5f72b22ea35d714a47059" // Replace
    };

    firebase.initializeApp(firebaseConfig);
    const database = firebase.database();
    const storage = firebase.storage(); // For screenshots

    // DOM Elements
    const menuItems = document.querySelectorAll('.admin-menu-item');
    const pages = document.querySelectorAll('.admin-page');
    const loadingOverlay = document.getElementById('admin-loading-overlay');
    const notificationContainer = document.getElementById('admin-notification-container');
    const modalBackdrop = document.getElementById('admin-modal-backdrop');

    // Dashboard Stats
    const totalUsersStat = document.getElementById('total-users-stat');
    const pendingDepositsStat = document.getElementById('pending-deposits-stat');
    const pendingWithdrawalsStat = document.getElementById('pending-withdrawals-stat');
    const totalSiteBalanceStat = document.getElementById('total-site-balance-stat');

    // Users Page
    const usersTableBody = document.getElementById('users-table-body');
    const userSearchInput = document.getElementById('user-search');

    // Deposits Page
    const depositsTableBody = document.getElementById('deposits-table-body');

    // Withdrawals Page
    const withdrawalsTableBody = document.getElementById('withdrawals-table-body');

    // Announcements Page
    const announcementTextInput = document.getElementById('announcement-text');
    const postAnnouncementBtn = document.getElementById('post-announcement-btn');
    const currentAnnouncementDisplay = document.getElementById('current-announcement-display');

    // Contact Messages Page
    const contactMessagesTableBody = document.getElementById('contact-messages-body');
    const viewMessageModal = document.getElementById('view-message-modal');

    // Settings Page
    const settingEasypaisaNumber = document.getElementById('setting-easypaisa-number');
    const settingEasypaisaName = document.getElementById('setting-easypaisa-name');
    const settingWithdrawalFee = document.getElementById('setting-withdrawal-fee');
    const settingMinWithdrawal = document.getElementById('setting-min-withdrawal');
    const saveSettingsBtn = document.getElementById('save-settings-btn');
    
    // Screenshot Modal
    const viewScreenshotModal = document.getElementById('view-screenshot-modal');
    const screenshotModalImgContainer = document.getElementById('screenshot-modal-img-container');


    let allUsersData = []; // To store all users for client-side search

    // --- Navigation ---
    menuItems.forEach(item => {
        item.addEventListener('click', () => {
            const pageId = item.dataset.page + '-page';
            navigateToPage(pageId, item);
        });
    });

    function navigateToPage(pageId, activeMenuItem) {
        pages.forEach(page => page.classList.add('hidden'));
        document.getElementById(pageId).classList.remove('hidden');

        menuItems.forEach(item => item.classList.remove('active'));
        if (activeMenuItem) activeMenuItem.classList.add('active');

        // Load data for the page
        if (pageId === 'dashboard-page') loadDashboardStats();
        else if (pageId === 'users-page') loadUsers();
        else if (pageId === 'deposits-page') loadPendingDeposits();
        else if (pageId === 'withdrawals-page') loadPendingWithdrawals();
        else if (pageId === 'announcements-page') loadCurrentAnnouncement();
        else if (pageId === 'contact-messages-page') loadContactMessages();
        else if (pageId === 'settings-page') loadSettings();

    }

    // --- Loading Indicators ---
    function showLoading() { loadingOverlay.classList.remove('hidden'); }
    function hideLoading() { loadingOverlay.classList.add('hidden'); }

    // --- Notifications ---
    function showNotification(message, type = 'info') {
        const notification = document.createElement('div');
        notification.className = `admin-notification ${type}`;
        let iconClass = 'fa-info-circle';
        if (type === 'success') iconClass = 'fa-check-circle';
        if (type === 'error') iconClass = 'fa-times-circle';
        notification.innerHTML = `<i class="fas ${iconClass}"></i> ${message}`;
        notificationContainer.appendChild(notification);
        setTimeout(() => notification.remove(), 4000);
    }

    // --- Modal Handling ---
    function openModal(modalId) {
        document.getElementById(modalId).classList.remove('hidden');
        modalBackdrop.classList.remove('hidden');
    }

    function closeModal(modalId) {
        document.getElementById(modalId).classList.add('hidden');
        modalBackdrop.classList.add('hidden');
    }

    document.querySelectorAll('.admin-modal-close').forEach(btn => {
        btn.addEventListener('click', () => closeModal(btn.dataset.modalId));
    });
    modalBackdrop.addEventListener('click', () => {
        document.querySelectorAll('.admin-modal').forEach(modal => modal.classList.add('hidden'));
        modalBackdrop.classList.add('hidden');
    });

    // --- Helper Functions ---
    function formatDate(isoString) {
        if (!isoString) return 'N/A';
        return new Date(isoString).toLocaleString('en-GB', { dateStyle: 'short', timeStyle: 'short' });
    }
    
    // --- Dashboard ---
    function loadDashboardStats() {
        showLoading();
        // Total Users
        database.ref('users').once('value', snapshot => {
            totalUsersStat.textContent = snapshot.numChildren();
            
            // Calculate total site balance (sum of all users' balance + earnings)
            let totalBalance = 0;
            snapshot.forEach(userSnap => {
                const userData = userSnap.val();
                totalBalance += (userData.balance || 0) + (userData.earnings || 0);
            });
            totalSiteBalanceStat.textContent = `${totalBalance.toFixed(2)} Rs`;

        }).catch(err => console.error("Error loading total users:", err));

        // Pending Deposits
        database.ref('admin/pending_deposits').orderByChild('status').equalTo('pending').on('value', snapshot => {
            pendingDepositsStat.textContent = snapshot.numChildren();
        }, err => console.error("Error loading pending deposits count:", err));


        // Pending Withdrawals
        database.ref('admin/pending_withdrawals').orderByChild('status').equalTo('pending').on('value', snapshot => {
            pendingWithdrawalsStat.textContent = snapshot.numChildren();
            hideLoading();
        }, err => console.error("Error loading pending withdrawals count:", err));
    }


    // --- User Management ---
    function loadUsers() {
        showLoading();
        database.ref('users').on('value', snapshot => {
            allUsersData = [];
            snapshot.forEach(userSnap => {
                allUsersData.push({ id: userSnap.key, ...userSnap.val() });
            });
            renderUsersTable(allUsersData);
            hideLoading();
        }, err => {
            showNotification('Error loading users: ' + err.message, 'error');
            hideLoading();
        });
    }

    userSearchInput.addEventListener('input', (e) => {
        const searchTerm = e.target.value.toLowerCase();
        const filteredUsers = allUsersData.filter(user => 
            user.name?.toLowerCase().includes(searchTerm) || 
            user.email?.toLowerCase().includes(searchTerm)
        );
        renderUsersTable(filteredUsers);
    });

    function renderUsersTable(users) {
        usersTableBody.innerHTML = '';
        if (users.length === 0) {
            usersTableBody.innerHTML = '<tr><td colspan="7" style="text-align:center;">No users found.</td></tr>';
            return;
        }
        users.forEach(user => {
            const row = usersTableBody.insertRow();
            const userStatus = user.status || 'active'; // Default to active if not set
            row.innerHTML = `
                <td>${user.name || 'N/A'}</td>
                <td>${user.email || 'N/A'}</td>
                <td>${(user.balance || 0).toFixed(2)}</td>
                <td>${(user.earnings || 0).toFixed(2)}</td>
                <td>${user.activePlan || 0}</td>
                <td><span class="status-badge ${userStatus}">${userStatus}</span></td>
                <td>
                    <button class="admin-btn primary small edit-user-btn" data-id="${user.id}">Edit</button>
                    <button class="admin-btn ${userStatus === 'banned' ? 'success' : 'danger'} small toggle-ban-btn" data-id="${user.id}" data-current-status="${userStatus}">
                        ${userStatus === 'banned' ? 'Unban' : 'Ban'}
                    </button>
                </td>
            `;
        });

        // Attach event listeners for edit and ban buttons
        document.querySelectorAll('.edit-user-btn').forEach(btn => {
            btn.addEventListener('click', () => openEditUserModal(btn.dataset.id));
        });
        document.querySelectorAll('.toggle-ban-btn').forEach(btn => {
            btn.addEventListener('click', () => toggleUserBan(btn.dataset.id, btn.dataset.currentStatus));
        });
    }

    function openEditUserModal(userId) {
        const user = allUsersData.find(u => u.id === userId);
        if (!user) return;

        document.getElementById('edit-user-id').value = userId;
        document.getElementById('edit-user-name-title').textContent = user.name || 'N/A';
        document.getElementById('edit-user-name').value = user.name || '';
        document.getElementById('edit-user-email').value = user.email || '';
        document.getElementById('edit-user-balance').value = (user.balance || 0).toFixed(2);
        document.getElementById('edit-user-earnings').value = (user.earnings || 0).toFixed(2);
        document.getElementById('edit-user-plan').value = user.activePlan || 0;
        document.getElementById('edit-user-status').value = user.status || 'active';
        openModal('edit-user-modal');
    }

    document.getElementById('save-user-changes-btn').addEventListener('click', () => {
        const userId = document.getElementById('edit-user-id').value;
        const updates = {
            name: document.getElementById('edit-user-name').value,
            balance: parseFloat(document.getElementById('edit-user-balance').value),
            earnings: parseFloat(document.getElementById('edit-user-earnings').value),
            activePlan: parseInt(document.getElementById('edit-user-plan').value) || null, // null if 0 or empty
            planStartDate: parseInt(document.getElementById('edit-user-plan').value) > 0 && !allUsersData.find(u => u.id === userId).activePlan ? new Date().toISOString() : (allUsersData.find(u => u.id === userId).planStartDate || null), // Set start date only if new plan
            status: document.getElementById('edit-user-status').value
        };

        if (isNaN(updates.balance) || isNaN(updates.earnings) || (updates.activePlan !== null && isNaN(updates.activePlan)) ) {
            showNotification('Invalid numeric values for balance, earnings or plan.', 'error');
            return;
        }

        showLoading();
        database.ref('users/' + userId).update(updates)
            .then(() => {
                showNotification('User updated successfully.', 'success');
                closeModal('edit-user-modal');
                // loadUsers(); // Data will update via 'on' listener
            })
            .catch(err => showNotification('Error updating user: ' + err.message, 'error'))
            .finally(hideLoading);
    });

    function toggleUserBan(userId, currentStatus) {
        const newStatus = currentStatus === 'banned' ? 'active' : 'banned';
        const confirmAction = confirm(`Are you sure you want to ${newStatus === 'banned' ? 'ban' : 'unban'} this user?`);
        if (!confirmAction) return;

        showLoading();
        database.ref(`users/${userId}/status`).set(newStatus)
            .then(() => {
                showNotification(`User ${newStatus === 'banned' ? 'banned' : 'unbanned'} successfully.`, 'success');
                // loadUsers(); // Data will update via 'on' listener
            })
            .catch(err => showNotification('Error updating user status: ' + err.message, 'error'))
            .finally(hideLoading);
    }

    // --- Deposit Management ---
    function loadPendingDeposits() {
        showLoading();
        // Listen for pending deposits in the admin queue
        database.ref('admin/pending_deposits').orderByChild('status').equalTo('pending').on('value', snapshot => {
            depositsTableBody.innerHTML = '';
            if (!snapshot.exists()) {
                depositsTableBody.innerHTML = '<tr><td colspan="8" style="text-align:center;">No pending deposits.</td></tr>';
                hideLoading();
                return;
            }
            snapshot.forEach(depSnap => {
                const deposit = { id: depSnap.key, ...depSnap.val() };
                const row = depositsTableBody.insertRow();
                row.innerHTML = `
                    <td>${deposit.userName || 'N/A'} (ID: ${deposit.userUid ? deposit.userUid.slice(0,5) : 'N/A'})</td>
                    <td>${deposit.amount.toFixed(2)}</td>
                    <td>${deposit.method}</td>
                    <td>${deposit.transactionId}</td>
                    <td>${deposit.senderNumber}</td>
                    <td>${formatDate(deposit.date)}</td>
                    <td>${deposit.screenshotUrl ? `<a href="#" class="screenshot-link" data-url="${deposit.screenshotUrl}">View</a>` : (deposit.screenshotFilename ? `<a href="#" class="screenshot-link" data-filename="${deposit.screenshotFilename}" data-userid="${deposit.userUid}">View (${deposit.screenshotFilename.slice(0,10)}...)</a>` : 'No')}</td>
                    <td>
                        <button class="admin-btn success small approve-deposit-btn" data-id="${deposit.id}" data-user-id="${deposit.userUid}" data-amount="${deposit.amount}">Approve</button>
                        <button class="admin-btn danger small reject-deposit-btn" data-id="${deposit.id}" data-user-id="${deposit.userUid}">Reject</button>
                    </td>
                `;
            });
             // Attach event listeners for screenshot links AFTER rendering table
            document.querySelectorAll('#deposits-table .screenshot-link').forEach(link => {
                link.addEventListener('click', (e) => {
                    e.preventDefault();
                    const url = e.target.dataset.url;
                    const filename = e.target.dataset.filename;
                    const userId = e.target.dataset.userid;
                    if (url) {
                        viewScreenshot(url);
                    } else if (filename && userId) {
                        viewScreenshotFromStorage(userId, filename);
                    }
                });
            });
            hideLoading();
        }, err => {
            showNotification('Error loading deposits: ' + err.message, 'error');
            hideLoading();
        });

        // Detach old listeners before attaching new ones to prevent multiple fires
        depositsTableBody.removeEventListener('click', handleDepositActions);
        depositsTableBody.addEventListener('click', handleDepositActions);
    }

    function handleDepositActions(e) {
        if (e.target.classList.contains('approve-deposit-btn')) {
            const depositId = e.target.dataset.id;
            const userId = e.target.dataset.userId;
            const amount = parseFloat(e.target.dataset.amount);
            approveDeposit(depositId, userId, amount);
        } else if (e.target.classList.contains('reject-deposit-btn')) {
            const depositId = e.target.dataset.id;
            const userId = e.target.dataset.userId;
            rejectDeposit(depositId, userId);
        }
    }

    function approveDeposit(depositId, userId, amount) {
        const reason = prompt("Optional: Add a note for approval.", "Approved by admin");
        if (reason === null) return; // User cancelled prompt

        showLoading();
        // 1. Update user's balance
        database.ref(`users/${userId}/balance`).transaction(currentBalance => {
            return (currentBalance || 0) + amount;
        })
        .then(() => {
            // 2. Update deposit status in user's deposits
            const userDepositUpdate = { status: 'completed', adminNote: reason, approvedDate: new Date().toISOString() };
            return database.ref(`users/${userId}/deposits/${depositId}`).update(userDepositUpdate);
        })
        .then(() => {
            // 3. Update/remove deposit from admin pending queue
             const adminDepositUpdate = { status: 'completed', adminNote: reason, processedBy: "admin_panel_user", processedDate: new Date().toISOString() }; // Example, add admin user if you have it
            return database.ref(`admin/pending_deposits/${depositId}`).update(adminDepositUpdate);
            // Or database.ref(`admin/pending_deposits/${depositId}`).remove();
            // Or move to admin/completed_deposits/${depositId}
        })
        .then(() => {
            // 4. Add to user's transaction log
            const transaction = {
                type: 'deposit_approval',
                amount: amount,
                date: new Date().toISOString(),
                description: `Deposit ${depositId.slice(0,5)} approved. ${reason}`
            };
            return database.ref(`users/${userId}/transactions`).push(transaction);
        })
        .then(() => {
            showNotification('Deposit approved and balance updated.', 'success');
        })
        .catch(err => showNotification('Error approving deposit: ' + err.message, 'error'))
        .finally(hideLoading);
    }

    function rejectDeposit(depositId, userId) {
        const reason = prompt("Reason for rejection (required):");
        if (!reason) {
            showNotification('Rejection reason is required.', 'error');
            return;
        }
        showLoading();
        const updates = { status: 'rejected', adminNote: reason, rejectedDate: new Date().toISOString() };
        // Update in user's record
        database.ref(`users/${userId}/deposits/${depositId}`).update(updates)
        .then(() => {
            // Update in admin queue
            const adminUpdates = { status: 'rejected', adminNote: reason, processedBy: "admin_panel_user", processedDate: new Date().toISOString() };
            return database.ref(`admin/pending_deposits/${depositId}`).update(adminUpdates);
            // Or move to admin/rejected_deposits/${depositId}
        })
        .then(() => {
            showNotification('Deposit rejected.', 'success');
        })
        .catch(err => showNotification('Error rejecting deposit: ' + err.message, 'error'))
        .finally(hideLoading);
    }

    // --- Withdrawal Management ---
    function loadPendingWithdrawals() {
        showLoading();
        database.ref('admin/pending_withdrawals').orderByChild('status').equalTo('pending').on('value', snapshot => {
            withdrawalsTableBody.innerHTML = '';
             if (!snapshot.exists()) {
                withdrawalsTableBody.innerHTML = '<tr><td colspan="9" style="text-align:center;">No pending withdrawals.</td></tr>';
                hideLoading();
                return;
            }
            snapshot.forEach(wdSnap => {
                const withdrawal = { id: wdSnap.key, ...wdSnap.val() };
                const row = withdrawalsTableBody.insertRow();
                row.innerHTML = `
                    <td>${withdrawal.userName || 'N/A'} (ID: ${withdrawal.userUid ? withdrawal.userUid.slice(0,5) : 'N/A'})</td>
                    <td>${withdrawal.requestedAmount.toFixed(2)}</td>
                    <td>${(withdrawal.fee || 0).toFixed(2)}</td>
                    <td>${(withdrawal.netAmount || withdrawal.requestedAmount).toFixed(2)}</td>
                    <td>${withdrawal.method}</td>
                    <td>${withdrawal.account}</td>
                    <td>${withdrawal.name}</td>
                    <td>${formatDate(withdrawal.date)}</td>
                    <td>
                        <button class="admin-btn success small approve-withdrawal-btn" data-id="${withdrawal.id}" data-user-id="${withdrawal.userUid}">Approve</button>
                        <button class="admin-btn danger small reject-withdrawal-btn" data-id="${withdrawal.id}" data-user-id="${withdrawal.userUid}" data-amount="${withdrawal.requestedAmount}">Reject</button>
                    </td>
                `;
            });
            hideLoading();
        }, err => {
            showNotification('Error loading withdrawals: ' + err.message, 'error');
            hideLoading();
        });

        withdrawalsTableBody.removeEventListener('click', handleWithdrawalActions);
        withdrawalsTableBody.addEventListener('click', handleWithdrawalActions);
    }

    function handleWithdrawalActions(e) {
        if (e.target.classList.contains('approve-withdrawal-btn')) {
            const withdrawalId = e.target.dataset.id;
            const userId = e.target.dataset.userId;
            approveWithdrawal(withdrawalId, userId);
        } else if (e.target.classList.contains('reject-withdrawal-btn')) {
            const withdrawalId = e.target.dataset.id;
            const userId = e.target.dataset.userId;
            const amount = parseFloat(e.target.dataset.amount);
            rejectWithdrawal(withdrawalId, userId, amount);
        }
    }

    function approveWithdrawal(withdrawalId, userId) {
        const reason = prompt("Optional: Add a note for approval (e.g., payment sent TID).", "Payment processed");
        if (reason === null) return;

        showLoading();
        const updates = { status: 'completed', adminNote: reason, approvedDate: new Date().toISOString() };
        // User's balance was already debited on request by the user app.
        // So, just update status.
        database.ref(`users/${userId}/withdrawals/${withdrawalId}`).update(updates)
        .then(() => {
            const adminUpdates = { status: 'completed', adminNote: reason, processedBy: "admin_panel_user", processedDate: new Date().toISOString() };
            return database.ref(`admin/pending_withdrawals/${withdrawalId}`).update(adminUpdates);
        })
        .then(() => {
            showNotification('Withdrawal approved.', 'success');
        })
        .catch(err => showNotification('Error approving withdrawal: ' + err.message, 'error'))
        .finally(hideLoading);
    }

    function rejectWithdrawal(withdrawalId, userId, amountToRefund) {
        const reason = prompt("Reason for rejection (required):");
        if (!reason) {
            showNotification('Rejection reason is required.', 'error');
            return;
        }
        showLoading();
        // 1. Refund amount to user (typically to earnings or balance, user app debited this)
        database.ref(`users/${userId}`).transaction(userData => {
            if (userData) {
                // Refund to earnings first, then balance if earnings isn't enough (or just refund to balance)
                // For simplicity here, refunding to earnings.
                userData.earnings = (userData.earnings || 0) + amountToRefund;
            }
            return userData;
        })
        .then(() => {
            // 2. Update withdrawal status in user's record
            const userWithdrawalUpdate = { status: 'rejected', adminNote: reason, rejectedDate: new Date().toISOString() };
            return database.ref(`users/${userId}/withdrawals/${withdrawalId}`).update(userWithdrawalUpdate);
        })
        .then(() => {
            // 3. Update/remove from admin queue
            const adminWithdrawalUpdate = { status: 'rejected', adminNote: reason, processedBy: "admin_panel_user", processedDate: new Date().toISOString() };
            return database.ref(`admin/pending_withdrawals/${withdrawalId}`).update(adminWithdrawalUpdate);
        })
         .then(() => {
            // 4. Add to user's transaction log for refund
            const transaction = {
                type: 'withdrawal_rejection_refund',
                amount: amountToRefund,
                date: new Date().toISOString(),
                description: `Withdrawal ${withdrawalId.slice(0,5)} rejected. Amount refunded. Reason: ${reason}`
            };
            return database.ref(`users/${userId}/transactions`).push(transaction);
        })
        .then(() => {
            showNotification('Withdrawal rejected and amount refunded to user.', 'success');
        })
        .catch(err => showNotification('Error rejecting withdrawal: ' + err.message, 'error'))
        .finally(hideLoading);
    }

    // --- Announcements ---
    function loadCurrentAnnouncement() {
        database.ref('app_settings/announcement').once('value', snapshot => {
            currentAnnouncementDisplay.textContent = snapshot.val() || 'No announcement set.';
        });
    }
    postAnnouncementBtn.addEventListener('click', () => {
        const text = announcementTextInput.value.trim();
        if (!text) {
            showNotification('Announcement text cannot be empty.', 'error');
            return;
        }
        showLoading();
        database.ref('app_settings/announcement').set(text)
            .then(() => {
                showNotification('Announcement posted.', 'success');
                announcementTextInput.value = '';
                loadCurrentAnnouncement(); // Refresh display
            })
            .catch(err => showNotification('Error posting announcement: ' + err.message, 'error'))
            .finally(hideLoading);
    });

    // --- Contact Messages ---
    function loadContactMessages() {
        showLoading();
        database.ref('contact_messages').orderByChild('date').limitToLast(50).on('value', snapshot => { // Show last 50
            contactMessagesTableBody.innerHTML = '';
            if (!snapshot.exists()) {
                contactMessagesTableBody.innerHTML = '<tr><td colspan="5" style="text-align:center;">No contact messages.</td></tr>';
                hideLoading();
                return;
            }
            const messages = [];
            snapshot.forEach(msgSnap => {
                messages.push({ id: msgSnap.key, ...msgSnap.val() });
            });
            messages.reverse(); // Show newest first

            messages.forEach(msg => {
                const row = contactMessagesTableBody.insertRow();
                row.innerHTML = `
                    <td>${formatDate(msg.date)}</td>
                    <td>${msg.name}</td>
                    <td>${msg.email}</td>
                    <td>${msg.subject}</td>
                    <td>
                        <button class="admin-btn primary small view-message-btn" data-id="${msg.id}">View</button>
                        <button class="admin-btn danger small delete-message-btn" data-id="${msg.id}">Delete</button>
                    </td>
                `;
            });
            hideLoading();
        }, err => {
            showNotification('Error loading messages: ' + err.message, 'error');
            hideLoading();
        });

        contactMessagesTableBody.removeEventListener('click', handleMessageActions);
        contactMessagesTableBody.addEventListener('click', handleMessageActions);
    }

    function handleMessageActions(e) {
        const target = e.target;
        if (target.classList.contains('view-message-btn')) {
            viewMessage(target.dataset.id);
        } else if (target.classList.contains('delete-message-btn')) {
            deleteMessage(target.dataset.id);
        }
    }

    function viewMessage(messageId) {
        database.ref(`contact_messages/${messageId}`).once('value', snapshot => {
            const msg = snapshot.val();
            if (!msg) return;
            document.getElementById('message-modal-name').textContent = msg.name;
            document.getElementById('message-modal-email').textContent = msg.email;
            document.getElementById('message-modal-date').textContent = formatDate(msg.date);
            document.getElementById('message-modal-subject').textContent = msg.subject;
            document.getElementById('message-modal-body').textContent = msg.message;
            openModal('view-message-modal');
        });
    }
    function deleteMessage(messageId) {
        if (confirm('Are you sure you want to delete this message?')) {
            showLoading();
            database.ref(`contact_messages/${messageId}`).remove()
                .then(() => showNotification('Message deleted.', 'success'))
                .catch(err => showNotification('Error deleting: ' + err.message, 'error'))
                .finally(hideLoading);
        }
    }
    
    // --- Settings ---
    function loadSettings() {
        showLoading();
        database.ref('app_settings').once('value', snapshot => {
            const settings = snapshot.val() || {};
            settingEasypaisaNumber.value = settings.easypaisaAccountNumber || '03130552446'; // Default from user app
            settingEasypaisaName.value = settings.easypaisaAccountName || 'NIDA ZAHRA'; // Default
            settingWithdrawalFee.value = (settings.withdrawalFeePercentage || 0.05) * 100; // Store as 0.05, display as 5
            settingMinWithdrawal.value = settings.minWithdrawalAmount || 200;
            hideLoading();
        }).catch(err => {
            showNotification('Error loading settings: ' + err.message, 'error');
            hideLoading();
        });
    }

    saveSettingsBtn.addEventListener('click', () => {
        const newSettings = {
            easypaisaAccountNumber: settingEasypaisaNumber.value.trim(),
            easypaisaAccountName: settingEasypaisaName.value.trim(),
            withdrawalFeePercentage: parseFloat(settingWithdrawalFee.value) / 100, // Store as decimal
            minWithdrawalAmount: parseInt(settingMinWithdrawal.value)
        };

        if (!newSettings.easypaisaAccountNumber || !newSettings.easypaisaAccountName || 
            isNaN(newSettings.withdrawalFeePercentage) || newSettings.withdrawalFeePercentage < 0 ||
            isNaN(newSettings.minWithdrawalAmount) || newSettings.minWithdrawalAmount < 0 ) {
            showNotification('Please enter valid settings values.', 'error');
            return;
        }
        
        showLoading();
        database.ref('app_settings').update(newSettings)
            .then(() => showNotification('Settings saved successfully!', 'success'))
            .catch(err => showNotification('Error saving settings: ' + err.message, 'error'))
            .finally(hideLoading);
    });
    
    // --- Screenshot Viewing ---
    function viewScreenshot(url) { // If URL is directly stored (not common for user uploads)
        screenshotModalImgContainer.innerHTML = `<img src="${url}" alt="Deposit Screenshot">`;
        openModal('view-screenshot-modal');
    }

    function viewScreenshotFromStorage(userId, filename) {
        if (!userId || !filename) {
            screenshotModalImgContainer.innerHTML = `<p>Error: Missing user ID or filename for screenshot.</p>`;
            openModal('view-screenshot-modal');
            return;
        }
        screenshotModalImgContainer.innerHTML = `<p>Loading image...</p>`;
        openModal('view-screenshot-modal');

        // Path in Firebase Storage where user app would upload
        const path = `user_screenshots/${userId}/${filename}`; 
        storage.ref(path).getDownloadURL()
            .then(url => {
                screenshotModalImgContainer.innerHTML = `<img src="${url}" alt="Screenshot for ${filename}">`;
            })
            .catch(error => {
                console.error("Error getting screenshot URL:", error);
                screenshotModalImgContainer.innerHTML = `<p>Could not load screenshot. It might not exist or access is denied. (Path: ${path})</p>`;
                showNotification('Error loading screenshot.', 'error');
            });
    }


    // Initial Load
    navigateToPage('dashboard-page', document.querySelector('.admin-menu-item[data-page="dashboard"]'));
});